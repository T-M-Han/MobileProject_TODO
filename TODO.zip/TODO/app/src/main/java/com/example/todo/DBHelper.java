package com.example.todo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    // Constructor for DBHelper
    public DBHelper(Context context) {
        super(context, "Todolistdata.db", null, 1);
    }

    // Method called when the database is created for the first time
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Creating the tasks table with columns: id, task, status, priority
        db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, task TEXT,"
                + "status INTEGER DEFAULT 0, priority TEXT DEFAULT 'none')");
    }

    // Method called when the database needs to be upgraded
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop the existing tasks table if it exists
        db.execSQL("DROP TABLE if exists tasks");
    }

    // Method to insert task data into the database
    public boolean insertTaskData(String task, String priority) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("task", task);
        contentValues.put("priority", priority);
        // Inserting data into tasks table
        long result = db.insert("tasks", null, contentValues);
        return result != -1;
    }

    // Method to update task data in the database
    public boolean updateData(String id, String newTaskText, String selectedPriority) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("task", newTaskText);
        contentValues.put("priority", selectedPriority);
        // Updating data in tasks table based on id
        long result = db.update("tasks", contentValues, "id=?", new String[]{id});
        db.close();
        return false;
    }

    // Method to update task status in the database
    public boolean updateTaskData(String task, int status){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("task", task);
        contentValues.put("status", status);
        // Checking if the task exists in the database
        Cursor cursor=db.rawQuery("SELECT * FROM tasks WHERE task=?", new String[]{task});
        if(cursor.getCount()>0) {
            // Updating task status
            long result = db.update("tasks", contentValues, "task=?", new String[]{task});
            if (result == -1) return false;
            else return true;
        }
        else{}
        return false;
    }

    // Method to delete task data from the database
    public boolean deleteTaskData(String id){
        SQLiteDatabase db=this.getWritableDatabase();
        // Checking if the task with given id exists in the database
        Cursor cursor=db.rawQuery("SELECT * FROM tasks WHERE id=?", new String[]{id});
        if(cursor.getCount()>0) {
            // Deleting task with given id
            long result = db.delete("tasks", "id=?", new String[]{id});
            if (result == -1) return false;
            else return true;
        }
        else{
            return false;
        }
    }

    // Method to select data from the tasks table with specified order
    public Cursor selectDataWithOrder(String orderBy) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {"id","task", "status", "priority"};
        // Querying tasks table with specified projection and order
        return db.query("tasks", projection, null, null, null, null, orderBy);
    }
}
