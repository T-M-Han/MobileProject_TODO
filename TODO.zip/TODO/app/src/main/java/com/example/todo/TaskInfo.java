package com.example.todo;

// TaskInfo class represents the structure of a task
public class TaskInfo {
    public String taskName; // Name of the task
    public boolean taskStatus; // Status of the task (completed or not)
    public String taskpriority; // Priority of the task
    public int id; // Unique identifier for the task in the database

    // Constructor to initialize TaskInfo object with provided values
    public TaskInfo(int id, String taskName, boolean taskStatus, String taskpriority) {
        super();
        this.taskName = taskName;
        this.taskStatus = taskStatus;
        this.taskpriority = taskpriority;
        this.id = id;
    }

    // Getter method to retrieve the task name
    public String getTaskName() {
        return taskName;
    }
}
