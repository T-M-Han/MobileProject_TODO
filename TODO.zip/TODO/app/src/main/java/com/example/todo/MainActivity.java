package com.example.todo;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ListView lstViewTasks;
    DBHelper db;
    TaskAdapter adapter;
    EditText edtNew;
    Spinner spinnerp;
    String selectedId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views and database helper
        edtNew = findViewById(R.id.edtNewTask);
        spinnerp = findViewById(R.id.spinnerPriority);
        Button btnNew = findViewById(R.id.btnNew);
        db = new DBHelper(MainActivity.this);
        lstViewTasks = findViewById(R.id.listviewTasks);

        // Set up the adapter for the list view
        adapter = new TaskAdapter(this, R.layout.activity_tasks, TaskAdapter.data);
        lstViewTasks.setAdapter(adapter);

        // Load existing data from the database
        selectData();

        // Button click listener for adding/updating tasks
        btnNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get task details from input fields
                Spinner spinnerPriority = findViewById(R.id.spinnerPriority);
                String selectedPriority = spinnerPriority.getSelectedItem().toString();
                EditText edtNewTask = findViewById(R.id.edtNewTask);
                String newTaskText = edtNewTask.getText().toString().trim();

                // Check if the button is in "ADD" or "UPDATE" mode
                String buttonText = btnNew.getText().toString();
                if ("ADD".equals(buttonText)) {
                    // Add a new task to the database
                    if (!newTaskText.isEmpty()) {
                        boolean check = db.insertTaskData(newTaskText, selectedPriority);
                        adapter.clear();
                        selectData();
                        edtNewTask.getText().clear();
                    } else {
                        Toast.makeText(MainActivity.this, "Task cannot be empty", Toast.LENGTH_SHORT).show();
                    }
                } else if ("UPDATE".equals(buttonText)) {
                    // Update an existing task in the database
                    db.updateData(selectedId, newTaskText, selectedPriority);
                    Toast.makeText(MainActivity.this, "Data is Updated", Toast.LENGTH_SHORT).show();
                    adapter.clear();
                    selectData();
                    btnNew.setText("ADD");
                    edtNewTask.getText().clear();
                }
            }
        });

        // Info button click listener
        ImageButton infobtn = findViewById(R.id.btninfo);
        infobtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showInfoDialog();
            }
        });

        // Delete all button click listener
        ImageButton deleteall = findViewById(R.id.btndeleteall);
        deleteall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showConfirmationDialog();
            }
        });

        // Long press listener for editing/deleting tasks
        lstViewTasks.post(() -> {
            for (int i = 0; i < lstViewTasks.getChildCount(); i++) {
                LinearLayout taskLayout = (LinearLayout) ((LinearLayout) lstViewTasks.getChildAt(i));
                taskLayout.setOnLongClickListener(v -> {
                    selectedId = ((TextView) ((LinearLayout) taskLayout.getChildAt(0)).getChildAt(2)).getText().toString();
                    showEditDialog(v, btnNew, taskLayout, selectedId);
                    return false;
                });
            }
        });
    }

    // Method to show the edit dialog for updating/deleting a task
    private void showEditDialog(View v, Button btn, LinearLayout taskLayout, String id) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Task");
        builder.setMessage("Update Or Delete this task?");
        builder.setNegativeButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Set button text to "UPDATE" mode
                btn.setText("UPDATE");

                // Populate fields with existing task details for editing
                String tasktitle = ((CheckBox) ((LinearLayout) taskLayout.getChildAt(0)).getChildAt(0)).getText().toString();
                edtNew.setText(tasktitle);

                String taskpri = ((TextView) ((LinearLayout) taskLayout.getChildAt(0)).getChildAt(1)).getText().toString();
                ArrayAdapter<String> adapter = (ArrayAdapter<String>) spinnerp.getAdapter();
                int position = adapter.getPosition(taskpri);
                spinnerp.setSelection(position);
            }
        });
        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Delete the selected task
                adapter.deleteData(v);
                selectData();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    // Method to show confirmation dialog before deleting all data
    private void showConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Confirmation");
        builder.setMessage("Are you sure you want to delete all data from the database?");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteAllDataFromDatabase();
                selectData();
                dialog.dismiss();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    // Method to delete all data from the database
    private void deleteAllDataFromDatabase() {
        SQLiteDatabase db = this.db.getWritableDatabase();
        db.delete("tasks", null, null);
        db.close();
    }

    // Method to retrieve and display data from the database
    public void selectData() {
        TaskAdapter.data.clear();

        // Select data from the database with ordering by priority
        Cursor cursor = db.selectDataWithOrder("CASE WHEN priority='High' THEN 3 " +
                "WHEN priority='Medium' THEN 2 " +
                "WHEN priority='Low' THEN 1 ELSE 0 END DESC");

        // Iterate through the cursor and populate the list
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String task = cursor.getString(cursor.getColumnIndexOrThrow("task"));
                int status = cursor.getInt(cursor.getColumnIndexOrThrow("status"));
                boolean s = status == 1;
                String taskp = cursor.getString(cursor.getColumnIndexOrThrow("priority"));
                TaskAdapter.data.add(new TaskInfo(id, task, s, taskp));
            } while (cursor.moveToNext());

            cursor.close();
        }
        adapter.notifyDataSetChanged();
    }

    // Method to show the information dialog
    private void showInfoDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Information and Guide!");
        builder.setMessage("Welcome Message:\n\n" +
                "\"Welcome to TODO! This Information and Guide section is here to help you make the most out of your to-do list experience. Let's get started!\"\n\n" +
                "Update and Delete:\n\n" +
                "\"Need to update or remove a task? Simply long press on the task, and tap 'Update' or 'Delete.' It's quick and easy!\"");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
