package com.example.todo;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class TaskAdapter extends ArrayAdapter<TaskInfo> {
    Context context;
    int layoutResourceId;
    static ArrayList<TaskInfo> data = new ArrayList<TaskInfo>(); // Holds the data for the adapter
    DBHelper db;

    // Constructor for the TaskAdapter
    public TaskAdapter(Context context, int layoutResourceId, ArrayList<TaskInfo> data) {
        super(context, layoutResourceId, data);
        this.layoutResourceId = layoutResourceId;
        this.context = context;
        this.data = data;
    }

    // getView method is called for each item in the ListView
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        TaskInfoHolder holder = null;

        if (row == null) {
            // Inflate the layout if the row is not yet created
            LayoutInflater inflater = ((Activity) context).getLayoutInflater();
            row = inflater.inflate(layoutResourceId, parent, false);

            // Create a holder object to hold the views
            holder = new TaskInfoHolder();
            holder.checkBox = row.findViewById(R.id.chkTask);
            holder.priorityTextView = row.findViewById(R.id.taskpriority);
            holder.txtId = row.findViewById(R.id.txtId);
            row.setTag(holder);
        } else {
            // If the row is already created, reuse the holder object
            holder = (TaskInfoHolder) row.getTag();
        }

        // Get the TaskInfo object for the current position
        TaskInfo taskInfo = data.get(position);

        // Set the values of views in the row using TaskInfo object
        holder.checkBox.setText(taskInfo.taskName);
        holder.checkBox.setChecked(taskInfo.taskStatus);
        holder.priorityTextView.setText(taskInfo.taskpriority);
        holder.txtId.setText(String.valueOf(taskInfo.id));

        // Apply design to checkbox based on its state
        setCheckBoxDesign(holder.checkBox, holder.priorityTextView);

        // Click listener for checkbox to update task status
        TaskInfoHolder finalHolder = holder;
        holder.checkBox.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                CheckBox cb = (CheckBox) v;
                db = new DBHelper(getContext());
                db.updateTaskData(cb.getText().toString(), cb.isChecked() ? 1 : 0);
                setCheckBoxDesign(cb, finalHolder.priorityTextView);
            }
        });

        return row;
    }

    // Method to delete data when checkbox is clicked
    public void deleteData(View v) {
        LinearLayout parentLayout = (LinearLayout) v;

        CheckBox cb = parentLayout.findViewById(R.id.chkTask);
        TextView id = parentLayout.findViewById(R.id.txtId);

        Toast.makeText(context, "Deleted: " + cb.getText().toString(), Toast.LENGTH_SHORT).show();

        db = new DBHelper(getContext());
        db.deleteTaskData(id.getText().toString());

        for (int i = 0; i < TaskAdapter.data.size(); i++) {
            if (TaskAdapter.data.get(i).getTaskName().equals(id.getText().toString())) {
                TaskAdapter.data.remove(i);
                notifyDataSetChanged();
            }
        }
    }

    // Method to set the design of checkbox based on its state
    private void setCheckBoxDesign(CheckBox cb, TextView taskPriority) {
        if (cb.isChecked()) {
            cb.setAlpha(0.3f);
            cb.setTypeface(null, Typeface.NORMAL);
            cb.setTextColor(Color.GRAY);

            taskPriority.setAlpha(0.3f);
            taskPriority.setTypeface(null, Typeface.NORMAL);
            taskPriority.setTextColor(Color.GRAY);
        } else {
            cb.setAlpha(1.0f);
            cb.setTypeface(null, Typeface.BOLD);
            cb.setTextColor(Color.WHITE);

            taskPriority.setAlpha(1.0f);
            taskPriority.setTypeface(null, Typeface.BOLD);
            taskPriority.setTextColor(Color.WHITE);
        }
    }

    // Holder class to hold views of each row in the ListView
    public class TaskInfoHolder {
        CheckBox checkBox;
        TextView priorityTextView;
        TextView txtId;
    }
}
