package com.example.todo;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

public class LoadingActivity extends AppCompatActivity {
    // Constant for splash screen timeout
    private static final int SPLASH_TIME_OUT = 2000;
    // Progress bar widget
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        // Set the layout for the loading activity
        setContentView(R.layout.activity_loading);

        // Initialize progress bar
        progressBar = findViewById(R.id.progressBar);

        // Create a handler to delay the intent to switch to the main activity
        Handler handler=new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Increase progress by 10
                int progress = progressBar.getProgress() + 10;
                progressBar.setProgress(progress);
                // If progress reaches 100, switch to the main activity
                if(progress >= 100){
                    Intent intent = new Intent(LoadingActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish(); // Finish current activity
                }
                // If progress is less than 100, continue updating progress and post delayed action
                else{
                    handler.postDelayed(this, 50); // Post a delayed action to run this Runnable again after 50 milliseconds
                }
            }
        }, SPLASH_TIME_OUT); // Post the initial delayed action after SPLASH_TIME_OUT milliseconds
    }
}
